<?php $__env->startSection('content'); ?>
    <div class="content-body">
        <div class="container-fluid">
            <div class="row page-titles mx-0">
                <div class="col-sm-6 p-md-0">
                    <h4>Hi, welcome back!</h4>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Admin</a></li>
                        <li class="breadcrumb-item active"><a href="#">Site Setting</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->
            <div class="row">
                <div class="col-xl-6 col-lg-6">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Software Fee</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-xl-2 col-lg-2">
                                    <button type="submit" class="btn btn-light"><?php echo e($SiteSetting->package_buy_charge); ?>$</button>
                                </div>
                                <div class="col-xl-5 col-lg-5">
                                    <div class="basic-form">
                                        <form method="POST" action="<?php echo e(url('save-site-setting')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <input type="text" class="form-control input" placeholder="Software Fee"
                                                    name="package_buy_charge" required>
                                            </div>
                                    </div>
                                </div>
                                <div class="col-xl-5 col-lg-5">
                                    <div class="basic-form">
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-primary w-100">Submit</button>
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-xxl-6 col-lg-6">
                    <div class="card border-0 pb-0">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Withdraw Charge</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-xl-2 col-lg-2">
                                        <button type="submit" class="btn btn-light"><?php echo e($SiteSetting->withdraw_charge); ?>%</button>
                                    </div>
                                    <div class="col-xl-5 col-lg-5">
                                        <div class="basic-form">
                                            <form method="POST" action="<?php echo e(url('save-site-setting')); ?>">
                                                <?php echo csrf_field(); ?>
                                                <div class="form-group">
                                                    <input type="text" class="form-control input"
                                                        placeholder="Withdraw Charge" name="withdraw_charge" required >
                                                </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-5 col-lg-5">
                                        <div class="basic-form">
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary w-100">Submit</button>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-12 col-xxl-12 col-lg-12">
                    <div class="card border-0 pb-0">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Social Informations</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-xl-6 col-lg-6">
                                        <div class="basic-form">
                                            <form method="POST" action="<?php echo e(url('save-site-setting')); ?>">
                                                <?php echo csrf_field(); ?>
                                                <div class="form-group">
                                                    <input type="text" class="form-control input" name="mobile_number" placeholder="Mobile Number" >
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" class="form-control input" name="email_id" placeholder="Email" />
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" class="form-control input" name="facebook" placeholder="Facebbok" >
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" class="form-control input" name="instagram" placeholder="instagram" >
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" class="form-control input" name="linkedin" placeholder="linkedin">
                                                </div>
                                                <button type="submit" class="btn btn-primary w-100">Submit</button>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-xl-6 col-lg-6">
                                        <div class="table">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th><?php echo e($SiteSetting->mobile_number); ?></th>
                                                    </tr>
                                                    <tr>
                                                        <th><?php echo e($SiteSetting->email_id); ?></th>
                                                    </tr>
                                                    <tr>
                                                        <th><?php echo e($SiteSetting->facebook); ?></th>
                                                    </tr>
                                                    <tr>
                                                        <th><?php echo e($SiteSetting->instagram); ?></th>
                                                    </tr>
                                                    <tr>
                                                        <th><?php echo e($SiteSetting->linkedin); ?></th>
                                                    </tr>
                                                </thead>

                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                

            </div>
        </div>



    <?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pikachuv2\pikachu\resources\views/backend/admin/pages/siteSetting.blade.php ENDPATH**/ ?>