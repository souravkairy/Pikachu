<?php echo $__env->yieldContent('header'); ?>
<?php echo $__env->yieldContent('sidebar'); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->yieldContent('footer'); ?>
<?php /**PATH D:\pikachuv2\pikachu\resources\views/backend/user/dashboard/index.blade.php ENDPATH**/ ?>