
<?php $__env->startSection('content'); ?>
    <?php
    $id = 1;
    ?>
    <div class="content-body">
        <div class="container-fluid">
            <div class="row page-titles mx-0">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text">
                        <h4>Hi, welcome back!</h4>
                    </div>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Admin</a></li>
                        <li class="breadcrumb-item active"><a href="<?php echo e(url('pending-packages')); ?>">Pending-Packages</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="example" class="display" style="min-width: 845px">
                                    <thead>
                                        <tr>
                                            <th>SL</th>
                                            <th>SS</th>
                                            <th>TxId</th>
                                            <th>Package</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $pendingPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($id); ?></td>
                                                <td>
                                                    <a href="<?php echo e(url('viewSS/'.$item->id)); ?>" type="button" class="btn btn-rounded btn-warning"
                                                       ><span class="btn-icon-left text-warning"><i class="fa fa-eye color-warning"></i>
                                                        </span>View ScreenShot
                                                    </a>
                                                </td>
                                                <td><?php echo e($item->txnId); ?></td>
                                                <td><?php echo e($item->package_name); ?></td>
                                                <td><span class="badge light badge-warning">Pending</span></td>
                                                <td>
                                                    <div class="dropdown">
                                                        <button type="button" class="btn btn-warning light sharp"
                                                            data-toggle="dropdown">
                                                            <svg width="20px" height="20px" viewBox="0 0 24 24"
                                                                version="1.1">
                                                                <g stroke="none" stroke-width="1" fill="none"
                                                                    fill-rule="evenodd">
                                                                    <rect x="0" y="0" width="24" height="24" />
                                                                    <circle fill="#000000" cx="5" cy="12" r="2" />
                                                                    <circle fill="#000000" cx="12" cy="12" r="2" />
                                                                    <circle fill="#000000" cx="19" cy="12" r="2" />
                                                                </g>
                                                            </svg>
                                                        </button>
                                                        <div class="dropdown-menu">
                                                            
                                                            <a class="dropdown-item" href="<?php echo e(url('activeUser/'.$item->user_id.'/'.$item->id)); ?>">Active</a>
                                                            <a class="dropdown-item" href="<?php echo e(url('declineUser/'.$item->id)); ?>">Decline</a>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php
                                                $id++;
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <h2>No New Pending Users</h2>
                                        <?php endif; ?>


                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pikachuv2\pikachu\resources\views/backend/admin/pages/pendingPackages.blade.php ENDPATH**/ ?>