
<?php $__env->startSection('sidebar'); ?>

    <!--**********************************
        Sidebar start
    ***********************************-->
    <div class="deznav">
        <div class="deznav-scroll">
            <ul class="metismenu" id="menu">
                <li><a href="<?php echo e(url('/admin/home')); ?>" aria-expanded="false">
                        <i class="flaticon-144-layout"></i>
                        <span class="nav-text">Dashboard</span>
                    </a>
                </li>
                <?php if(Auth::user()->user == 1): ?>
                <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                        <i class="flaticon-077-menu-1"></i>
                        <span class="nav-text">Users</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="<?php echo url('new-users'); ?>">New Users</a></li>
                        <li><a href="<?php echo url('active-users'); ?>">Active Users</a></li>
                        <li><a href="<?php echo url('de-actived-users'); ?>">De-Avtive Users</a></li>
                        <li><a href="<?php echo url('pending-packages'); ?>">Pending Packages</a></li>
                        <li><a href="<?php echo url('active-packages'); ?>">Avtive Packages</a></li>
                        <li><a href="<?php echo url('de-actived-packages'); ?>">De-Avtive Packages</a></li>

                    </ul>
                </li>

                <?php else: ?>
                <?php endif; ?>
                <?php if(Auth::user()->withdraw == 1): ?>

                <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                    <i class="flaticon-381-network"></i>
                    <span class="nav-text">Withdraw</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="<?php echo url('pending-withdraw-list'); ?>">Pending Request</a></li>
                    <li><a href="<?php echo url('completed-withdraw-list'); ?>">Completed Withdraw</a></li>
                </ul>

            </li>


                </li>
                <?php else: ?>
                <?php endif; ?>
                <?php if(Auth::user()->workStation == 1): ?>

                <li><a href="<?php echo url('work-station-setting'); ?>" aria-expanded="false">
                        <i class="flaticon-061-puzzle"></i>
                        <span class="nav-text">Work Station Setting</span>
                    </a>
                </li>
                <?php else: ?>
                <?php endif; ?>
                <?php if(Auth::user()->wallet == 1): ?>
                <li><a href="<?php echo url('wallet-setting'); ?>" aria-expanded="false">
                        <i class="flaticon-003-diamond"></i>
                        <span class="nav-text">Wallet Setting</span>
                    </a>
                </li>
                <?php else: ?>
                <?php endif; ?>
                <?php if(Auth::user()->package == 1): ?>
                <li><a href="<?php echo url('package-setting'); ?>" class="ai-icon" aria-expanded="false">
                        <i class="flaticon-381-settings-1"></i>
                        <span class="nav-text">Package Setting</span>
                    </a>
                </li>
                <?php else: ?>
                <?php endif; ?>
                <?php if(Auth::user()->commission == 1): ?>
                <li><a href="<?php echo url('commisions-setting'); ?>" class="ai-icon" aria-expanded="false">
                    <i class="flaticon-381-settings-3"></i>
                    <span class="nav-text">Commisions Setting</span>
                </a>
                </li>
                <?php else: ?>
                <?php endif; ?>
                <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                        <i class="flaticon-053-heart"></i>
                        <span class="nav-text">Contact Messages</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="<?php echo e(url('contact-inbox')); ?>">Inbox</a></li>
                        
                    </ul>
                </li>

                 <?php if(Auth::user()->setting == 1): ?>
                <li><a href="<?php echo e(url('site-setting')); ?>" class="ai-icon" aria-expanded="false">
                        <i class="flaticon-381-settings-2"></i>
                        <span class="nav-text">Site-Setting</span>
                    </a>
                </li>
                <?php else: ?>
                <?php endif; ?>
                <?php if(Auth::user()->type == 1): ?>
                <li><a href="<?php echo e(route('user-role')); ?>" aria-expanded="false">
                        <i class="flaticon-044-file"></i>
                        <span class="nav-text">Admin-Role-Setting</span>
                    </a>
                </li>
                <?php else: ?>
                <?php endif; ?>
            </ul>
            <div class="copyright">
                <p><strong>PIKAFUTURE Admin Dashboard</strong> © 2021 All Rights Reserved</p>
            </div>
        </div>
    </div>
    <!--**********************************
        Sidebar end
    ***********************************-->
<?php $__env->stopSection(); ?>




<?php echo $__env->make('backend.admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pikachuv2\pikachu\resources\views/backend/admin/elements/_sidebar.blade.php ENDPATH**/ ?>