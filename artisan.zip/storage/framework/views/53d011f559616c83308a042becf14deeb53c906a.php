<?php echo e($slot); ?>

<?php /**PATH D:\pikachuv2\pikachu\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>