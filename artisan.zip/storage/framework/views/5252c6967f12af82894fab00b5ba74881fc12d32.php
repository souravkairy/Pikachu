
<?php $__env->startSection('content'); ?>
              <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
			<div class="container-fluid">
                <!-- row -->
                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $packageData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-xl-4 col-lg-12 col-sm-12">
						<div class="card overflow-hidden">
							<div class="text-center p-5 overlay-box" style="background-image: url(images/big/img5.jpg);">
								<img src="<?php echo e(asset('Backend/assets/images/profile/profile.png')); ?>" width="100" class="img-fluid rounded-circle" alt="">
								<h3 class="mt-3 mb-0 text-white"><?php echo e($item->package_name); ?></h3>
							</div>
                            <div class="card-body">
								<div class="row text-center">
                                    <div class="col-2">
                                    </div>
									<div class="col-8">
										<div class="bgl-primary rounded p-3">
											<h4 class="mb-0"><?php echo e($item->package_price); ?>$</h4>
										</div>
									</div>
                                    <div class="col-2">
                                    </div>

								</div>
                            <h6 class="text-center pt-2">Trading Rate <?php echo e($item->trading_rate); ?>$ Per day</h6>
                            </div>
							<div class="card-footer mt-0">
                                <form action="<?php echo e(url('package-buying-process')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="package_name" value="<?php echo e($item->package_name); ?>">
                                    <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                    <input type="hidden" name="package_price" value="<?php echo e($item->package_price); ?>">
                                    <button class="btn btn-primary btn-lg btn-block" type="submit">BUY</button>
                                </form>
                            </div>
                        </div>
					</div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h2>No Package Available</h2>
                    <?php endif; ?>

                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pikachuv2\pikachu\resources\views/backend/user/pages/userPackage.blade.php ENDPATH**/ ?>