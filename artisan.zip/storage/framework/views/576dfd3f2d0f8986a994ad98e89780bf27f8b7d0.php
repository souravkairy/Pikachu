
<?php $__env->startSection('content'); ?>
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
			<div class="container-fluid">
				<div class="row">
                    <div class="col-xl-4 col-xxl-4 col-lg-4 col-sm-12">
						<div class="widget-stat card">
							<div class="card-body p-4">
								<div class="media ai-icon">
									<span class="mr-3 bgl-success text-success">
										<svg id="icon-customers" xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user">
											<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
											<circle cx="12" cy="7" r="4"></circle>
										</svg>
									</span>
									<div class="media-body">
										<p class="mb-1">Active Users</p>
										<h4 class="mb-0"><?php echo e($activePackages); ?></h4>
										<span class="badge badge-success">Peoples</span>
									</div>
								</div>
							</div>
						</div>
                    </div>
                    <div class="col-xl-4 col-xxl-4 col-lg-4 col-sm-12">
                        <div class="widget-stat card">
							<div class="card-body p-4">
								<div class="media ai-icon">
									<span class="mr-3 bgl-warning text-warning">
										<svg id="icon-customers" xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user">
											<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
											<circle cx="12" cy="7" r="4"></circle>
										</svg>
									</span>
									<div class="media-body">
										<p class="mb-1">Pending Users</p>
										<h4 class="mb-0"><?php echo e($pendingUsers); ?></h4>
										<span class="badge badge-warning">Peoples</span>
									</div>
								</div>
							</div>
						</div>
                    </div>
                    <div class="col-xl-4 col-xxl-4 col-lg-4 col-sm-12">
                        <div class="widget-stat card">
							<div class="card-body  p-4">
								<div class="media ai-icon">
									<span class="mr-3 bgl-primary text-primary">
										<svg id="icon-customers" xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user">
											<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
											<circle cx="12" cy="7" r="4"></circle>
										</svg>
									</span>
									<div class="media-body">
										<p class="mb-1">New Acounts</p>
										<h4 class="mb-0"><?php echo e($newUser); ?></h4>
										<span class="badge badge-primary">Peoples</span>
									</div>
								</div>
							</div>
						</div>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-xxl-3 col-lg-3 m-t35">
						<div class="card card-coin">
							<div class="card-body text-center">
                                <img  class="mb-3 currency-icon" style="width: 45%" src="<?php echo e(asset('BackEnd/assets/images/svg/privacy.svg')); ?>" alt="">
								<h2 class="text-black mb-2 font-w600">$<?php echo e($totalActivePackageAmount); ?></h2>
                                <div class="media-body">
                                    <span class="badge badge-success">Total Deposide</span>
                                </div>
							</div>
						</div>
					</div>
                    <div class="col-xl-3 col-sm-6 col-xxl-3 col-lg-3 m-t35">
						<div class="card card-coin">
							<div class="card-body text-center">
                                <img  class="mb-3 currency-icon" style="width: 45%" src="<?php echo e(asset('BackEnd/assets/images/svg/withdrawal (1).svg')); ?>" alt="">
								<h2 class="text-black mb-2 font-w600"><?php echo e($p_withdraw); ?>$</h2>
                                <div class="media-body">
                                    <span class="badge badge-dark">pending withdraw</span>
                                </div>
							</div>
						</div>
					</div>
                    <div class="col-xl-3 col-sm-6 col-xxl-3 col-lg-3 m-t35">
						<div class="card card-coin">
							<div class="card-body text-center">
                                <img  class="mb-3 currency-icon" style="width: 45%" src="<?php echo e(asset('BackEnd/assets/images/svg/withdrawal.svg')); ?>" alt="">
								<h2 class="text-black mb-2 font-w600"><?php echo e($c_withdraw); ?>$</h2>
                                <div class="media-body">
                                    <span class="badge badge-warning">Completed Withdraw</span>
                                </div>
							</div>
						</div>
					</div>
                    <div class="col-xl-3 col-sm-6 col-xxl-3 col-lg-3 m-t35">
						<div class="card card-coin">
							<div class="card-body text-center">
                                <img  class="mb-3 currency-icon" style="width: 45%" src="<?php echo e(asset('BackEnd/assets/images/svg/withdrawal (1).svg')); ?>" alt="">
								<h2 class="text-black mb-2 font-w600">-----</h2>
                                <div class="media-body">
                                    <span class="badge badge-primary">Blank</span>
                                </div>
							</div>
						</div>
					</div>
                    <div class="col-xl-4 col-xxl-4 col-lg-4 col-sm-12">
						<div class="widget-stat card">
							<div class="card-body p-4">
								<div class="media ai-icon">
									<span class="mr-3 bgl-success text-success">
                                        <img style="width: 70%" src="<?php echo e(asset('BackEnd/assets/images/svg/cheque.svg')); ?>" alt="">
									</span>
									<div class="media-body">
										<p class="mb-1">Active Packages</p>
										<h4 class="mb-0"><?php echo e($all_package); ?></h4>
										<span class="badge badge-success">----</span>
									</div>
								</div>
							</div>
						</div>
                    </div>
                    <div class="col-xl-4 col-xxl-4 col-lg-4 col-sm-12">
						<div class="widget-stat card">
							<div class="card-body p-4">
								<div class="media ai-icon">
									<span class="mr-3 bgl-success text-success">
                                        <img style="width: 70%" src="<?php echo e(asset('BackEnd/assets/images/svg/unauthorized-person.svg')); ?>" alt="">
									</span>
									<div class="media-body">
										<p class="mb-1">Total Admins</p>
										<h4 class="mb-0">---</h4>
										<span class="badge badge-success">Peoples</span>
									</div>
								</div>
							</div>
						</div>
                    </div>
                    <div class="col-xl-4 col-xxl-4 col-lg-4 col-sm-12">
						<div class="widget-stat card">
							<div class="card-body p-4">
								<div class="media ai-icon">
									<span class="mr-3 bgl-success text-success">
                                        <img style="width: 70%" src="<?php echo e(asset('BackEnd/assets/images/svg/audience.svg')); ?>" alt="">
									</span>
									<div class="media-body">
										<p class="mb-1">Total Visitors</p>
										<h4 class="mb-0">---</h4>
										<span class="badge badge-success">Peoples</span>
									</div>
								</div>
							</div>
						</div>
                    </div>
				</div>
				
				
			</div>
		</div>
        <!--**********************************
            Content body end
        ***********************************-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pikachuv2\pikachu\resources\views/backend/admin/pages/dashboard.blade.php ENDPATH**/ ?>