
<?php $__env->startSection('sidebar'); ?>

    <!--**********************************
        Sidebar start
    ***********************************-->
    <div class="deznav">
        <div class="deznav-scroll">
            <ul class="metismenu" id="menu">
                <li><a href="<?php echo e(url('/admin/home')); ?>" aria-expanded="false">
                        <i class="flaticon-144-layout"></i>
                        <span class="nav-text">Dashboard</span>
                    </a>
                </li>
                <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                        <i class="flaticon-077-menu-1"></i>
                        <span class="nav-text">Users</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="<?php echo url('new-users'); ?>">New User</a></li>
                        <li><a href="<?php echo url('pending-users'); ?>">Pending User</a></li>
                        <li><a href="<?php echo url('active-users'); ?>">Active User</a></li>

                    </ul>
                </li>
                <li><a href="<?php echo url('work-station-setting'); ?>" aria-expanded="false">
                        <i class="flaticon-061-puzzle"></i>
                        <span class="nav-text">Work Station Setting</span>
                    </a>
                </li>
                <li><a href="<?php echo url('wallet-setting'); ?>" aria-expanded="false">
                        <i class="flaticon-003-diamond"></i>
                        <span class="nav-text">Wallet Setting</span>
                    </a>
                </li>
                <li><a href="<?php echo url('package-setting'); ?>" class="ai-icon" aria-expanded="false">
                        <i class="flaticon-381-settings-1"></i>
                        <span class="nav-text">Package Setting</span>
                    </a>
                </li>
                <li><a href="<?php echo url('commisions-setting'); ?>" class="ai-icon" aria-expanded="false">
                    <i class="flaticon-381-settings-3"></i>
                    <span class="nav-text">Commisions Setting</span>
                </a>
                </li>
                <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                        <i class="flaticon-053-heart"></i>
                        <span class="nav-text">Contact Messages</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="<?php echo e(url('contact-inbox')); ?>">Inbox</a></li>
                        <li><a href="#">Sent</a></li>
                    </ul>
                </li>
                <li><a href="#" class="ai-icon" aria-expanded="false">
                        <i class="flaticon-381-settings-2"></i>
                        <span class="nav-text">Site-Setting</span>
                    </a>
                </li>
                <li><a href="#" aria-expanded="false">
                        <i class="flaticon-044-file"></i>
                        <span class="nav-text">Admin-Role-Setting</span>
                    </a>
                </li>
            </ul>
            <div class="copyright">
                <p><strong>Pikachu Admin Dashboard</strong> © 2021 All Rights Reserved</p>
            </div>
        </div>
    </div>
    <!--**********************************
        Sidebar end
    ***********************************-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pikachuv2\pikachu\resources\views/backend/admin/elements/_sidebar.blade.php ENDPATH**/ ?>