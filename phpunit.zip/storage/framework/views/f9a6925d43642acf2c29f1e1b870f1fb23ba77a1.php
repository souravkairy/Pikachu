
<?php $__env->startSection('sidebar'); ?>

        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li><a href="<?php echo e(url('/user-wallet')); ?>" aria-expanded="false">
							<i class="flaticon-144-layout"></i>
							<span class="nav-text">My Wallet</span>
						</a>
                    </li>
                    <li><a href="<?php echo url('user-work-station'); ?>" aria-expanded="false">
						<i class="flaticon-077-menu-1"></i>
							<span class="nav-text">Work Station</span>
						</a>
                    </li>
                    <li><a href="<?php echo url('packages'); ?>" aria-expanded="false">
							<i class="flaticon-003-diamond"></i>
							<span class="nav-text">Buy Package</span>
						</a>
                    </li>
                    <li><a href="<?php echo url('user-add-member'); ?>" aria-expanded="false">
                        <i class="flaticon-061-puzzle"></i>
                        <span class="nav-text">Add Member</span>
                    </a>
                    </li>
                    <li><a href="<?php echo url('downline-members'); ?>" aria-expanded="false">
                        <i class="flaticon-381-network"></i>
                        <span class="nav-text">Downline Members</span>
                    </a>
                    </li>

                </ul>
				<div class="copyright">
					<p><strong>Pikachu Admin Dashboard</strong> © 2021 All Rights Reserved</p>
					
				</div>
			</div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pikachuv2\pikachu\resources\views/backend/user/elements/_sidebar.blade.php ENDPATH**/ ?>