<?php $__env->startSection('footer'); ?>
       <!--**********************************
            Footer start
        ***********************************-->
        
        <!--**********************************
            Footer end
        ***********************************-->





		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="<?php echo e(asset('BackEnd/assets/vendor//global/global.min.js')); ?>"></script>
	<script src="<?php echo e(asset('BackEnd/assets/vendor//bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
	<script src="<?php echo e(asset('BackEnd/assets/vendor//chart.js/Chart.bundle.min.js')); ?>"></script>

    <script src="<?php echo e(asset('BackEnd/assets/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('BackEnd/assets/js/plugins-init/datatables.init.js')); ?>"></script>

	<!-- Chart piety plugin files -->
    <script src="<?php echo e(asset('BackEnd/assets/vendor//peity/jquery.peity.min.js')); ?>"></script>

	<!-- Apex Chart -->
	<script src="<?php echo e(asset('BackEnd/assets/vendor//apexchart/apexchart.js')); ?>"></script>

	<!-- Dashboard 1 -->
	<script src="<?php echo e(asset('BackEnd/assets/js/dashboard/dashboard-1.js')); ?>"></script>

	<script src="<?php echo e(asset('BackEnd/assets/vendor//owl-carousel/owl.carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('BackEnd/assets/js/custom.min.js')); ?>"></script>
	<script src="<?php echo e(asset('BackEnd/assets/js/deznav-init.js')); ?>"></script>



</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pikachuv2\pikachu\resources\views/backend/admin/elements/_footer.blade.php ENDPATH**/ ?>