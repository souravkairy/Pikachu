<?php $__env->startSection('content'); ?>
    <?php
    //    echo "<pre>";
    //    print_r($activePackages);
    //    exit();
    ?>
    <!--**********************************
                    Content body start
                ***********************************-->
    <div class="content-body">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-12 mt-2">
                    <div class="card">
                        <div class="card-header d-sm-flex d-block pb-0 border-0">
                            <div>
                                <h4 class="fs-20 text-black">First Level <strong>(<?php echo e($level1->count()); ?>p)</strong></h4>
                                <p class="mb-0 fs-12">From first level refer you will get 12% from profit</p>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="testimonial-one px-4 owl-right-nav owl-carousel owl-loaded owl-drag">
                                <?php $__empty_1 = true; $__currentLoopData = $level1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="items">
                                    <div class="text-center">
                                        <img class="mb-3 rounded"
                                            src="<?php echo e(asset('Backend/assets/images/contacts/Untitled-1.jpg')); ?>" alt="">
                                        <h5 class="mb-0"><a class="text-black" href="javascript:void(0);"><?php echo e($item->ref_link); ?></a></h5>
                                        
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-12 mt-2">
                    <div class="card">
                        <div class="card-header d-sm-flex d-block pb-0 border-0">
                            <div>
                                <h4 class="fs-20 text-black">Second Level <strong>(<?php echo e($level2->count()); ?>p)</strong></h4>
                                <p class="mb-0 fs-12">From first level refer you will get 8% from profit</p>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="testimonial-one px-4 owl-right-nav owl-carousel owl-loaded owl-drag">
                                <?php $__empty_1 = true; $__currentLoopData = $level2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="items">
                                    <div class="text-center">
                                        <img class="mb-3 rounded"
                                            src="<?php echo e(asset('Backend/assets/images/contacts/Untitled-1.jpg')); ?>" alt="">
                                        <h5 class="mb-0"><a class="text-black" href="javascript:void(0);"><?php echo e($item->ref_link); ?></a></h5>
                                        
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-12 mt-2">
                    <div class="card">
                        <div class="card-header d-sm-flex d-block pb-0 border-0">
                            <div>
                                <h4 class="fs-20 text-black">Third Level <strong>(<?php echo e($level3->count()); ?>p)</strong></h4>
                                <p class="mb-0 fs-12">From first level refer you will get 5% from profit</p>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="testimonial-one px-4 owl-right-nav owl-carousel owl-loaded owl-drag">
                                <?php $__empty_1 = true; $__currentLoopData = $level3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="items">
                                    <div class="text-center">
                                        <img class="mb-3 rounded"
                                            src="<?php echo e(asset('Backend/assets/images/contacts/Untitled-1.jpg')); ?>" alt="">
                                        <h5 class="mb-0"><a class="text-black" href="javascript:void(0);"><?php echo e($item->ref_link); ?></a></h5>
                                        
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    <!--**********************************
                    Content body end
                ***********************************-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pikachuv2\pikachu\resources\views/backend/user/pages/dowlineMembers.blade.php ENDPATH**/ ?>