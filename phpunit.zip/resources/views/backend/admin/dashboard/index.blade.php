@yield('header')
@yield('sidebar')
@yield('content')
@yield('footer')
